export const CATEGORIAS = [
    { nome: 'Alimentação', limite: 15 },
    { nome: 'Transporte', limite: 15 },
    { nome: 'Lazer', limite: 20 }
];