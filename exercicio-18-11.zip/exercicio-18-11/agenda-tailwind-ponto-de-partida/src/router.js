import { createRouter, createWebHashHistory } from 'vue-router';
import PaginaAgenda from './pages/PaginaAgenda.vue';
import PaginaMetas from './pages/PaginaMetas.vue';
import PaginaNovaEntrega from './pages/PaginaNovaEntrega.vue';
import PaginaEntrega from './pages/PaginaEntrega.vue';

const rotas = [
    { path: '/', component: PaginaAgenda },
    { path: '/nova', component: PaginaNovaEntrega },
    { path: '/entrega/:id', component: PaginaEntrega },
    { path: '/metas/:id', component: PaginaMetas }
];

export const router = createRouter({
    history: createWebHashHistory(),
    routes: rotas
});
