<script setup>
import { computed } from 'vue';

    const TIPOS = [
        { tipo: 'prova', titulo: 'Provas' },
        { tipo: 'trabalho', titulo: 'Trabalhos' },
        { tipo: 'apresentacao', titulo: 'Apresentações' }
    ];
    const tipos = computed(() => TIPOS.map((tipo) => montarTipo-(tipo)));

    function montarTipos(tipos) {
    const gastosDaCategoria = gastos.value.filter((gasto) => gasto.categoria === categoria.nome);
    const gasto = calcularTotal(gastosDaCategoria);
    return {
        nome: categoria.nome,
        limite: categoria.limite,
        gasto: gasto,
        porcentagem: calcularPorcentagem(gasto, categoria.limite)
    };
}

</script>

