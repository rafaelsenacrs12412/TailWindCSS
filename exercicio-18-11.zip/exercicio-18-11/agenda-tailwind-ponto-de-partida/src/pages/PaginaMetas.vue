<script setup>
import { computed } from 'vue';
import { formatarReais, calcularTotal, calcularPorcentagem } from '../calculos.js';
import { gastos, CATEGORIAS } from '../gastos.js';

// Uma meta para cada categoria: o limite, quanto já foi gasto e a porcentagem.
const metas = computed(() => CATEGORIAS.map((categoria) => montarMeta(categoria)));

function montarMeta(categoria) {
    const gastosDaCategoria = gastos.value.filter((gasto) => gasto.categoria === categoria.nome);
    const gasto = calcularTotal(gastosDaCategoria);
    return {
        nome: categoria.nome,
        limite: categoria.limite,
        gasto: gasto,
        porcentagem: calcularPorcentagem(gasto, categoria.limite)
    };
}

// montarSituacao({ gasto: 12.5, limite: 15 }) → 'Ainda dá para gastar R$ 2,50'
function montarSituacao(meta) {
    if (meta.gasto > meta.limite) {
        return `Passou ${formatarReais(meta.gasto - meta.limite)} do limite`;
    }
    return `Ainda dá para gastar ${formatarReais(meta.limite - meta.gasto)}`;
}
</script>

<template>
    <main>
        <h2>Metas da semana</h2>
        <p>Quanto já foi gasto em cada categoria, perto do limite.</p>

        <div>
            <section v-for="meta in metas" :key="meta.nome">
                <h3>{{ meta.nome }}</h3>
                <p>{{ Math.round(meta.porcentagem) }}%</p>
                <p>{{ formatarReais(meta.gasto) }} de {{ formatarReais(meta.limite) }}</p>
                <p>{{ montarSituacao(meta) }}</p>
            </section>
        </div>
    </main>
</template>
