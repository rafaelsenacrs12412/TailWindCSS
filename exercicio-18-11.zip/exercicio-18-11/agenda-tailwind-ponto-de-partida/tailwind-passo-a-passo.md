# A página Metas com Tailwind — passo a passo

Vamos dar ao controle de gastos uma página nova, **Metas** (`#/metas`): para
cada categoria, quanto já foi gasto perto do limite da semana, com uma barra
de progresso. Toda a aparência da página é feita **só com classes do
Tailwind**. As páginas que já existem continuam com o `style.css` de sempre.

**Ponto de partida:** o seu controle de gastos de segunda ou, se você não
tiver, a pasta `gastos-tailwind-ponto-de-partida` (`npm install` e
`npm run dev` dentro dela).

Lembre do Node portátil em cada terminal novo:

```
$env:Path = "$HOME\node-v26.13.0-win-x64;$env:Path"
```

---

## Pedaço 1 — O Tailwind instalado

1. No terminal, dentro do projeto:

   ```
   npm install tailwindcss @tailwindcss/vite
   ```

2. No `vite.config.js`, o plugin, ao lado do `vue()`:

   ```js
   import vue from '@vitejs/plugin-vue'
   import tailwindcss from '@tailwindcss/vite'
   import { defineConfig } from 'vite'

   // https://vite.dev/config/
   export default defineConfig({
     plugins: [vue(), tailwindcss()],
   })
   ```

3. No **topo** do `src/style.css`, antes de tudo:

   ```css
   @layer theme, base, components, utilities;
   @import "tailwindcss/theme.css" layer(theme);
   @import "tailwindcss/utilities.css" layer(utilities);

   @layer base {
   ```

4. No **fim** do `src/style.css`, feche a chave:

   ```css
   }
   ```

   Todo o CSS que já existia fica entre a chave que abre e a que fecha.

**O que é cada coisa**

- **As três primeiras linhas:** o Tailwind, sem o *preflight* (a parte que
  zera os estilos do navegador e mudaria as páginas que já existem). Num
  projeto novo, bastaria `@import "tailwindcss";`.
- **`@layer base { ... }`:** o CSS antigo vai para uma camada de baixo, e
  as classes do Tailwind ficam na de cima (`utilities`). A camada de cima
  ganha sempre. Sem isso, o CSS antigo ganharia das classes.

**Funcionou se:** o app continua igual. Teste: ponha `class="underline"` no
`<h1>` do `CabecalhoApp.vue`; o título fica sublinhado. Depois, tire.

---

## Pedaço 2 — A página Metas, sem estilo

1. No `src/gastos.js`, cada categoria ganha um limite por semana:

   ```js
   export const CATEGORIAS = [
       { nome: 'Alimentação', limite: 15 },
       { nome: 'Transporte', limite: 15 },
       { nome: 'Lazer', limite: 20 }
   ];
   ```

2. Crie a `src/pages/PaginaMetas.vue`:

   ```html
   <script setup>
   import { computed } from 'vue';
   import { formatarReais, calcularTotal, calcularPorcentagem } from '../calculos.js';
   import { gastos, CATEGORIAS } from '../gastos.js';

   // Uma meta para cada categoria: o limite, quanto já foi gasto e a porcentagem.
   const metas = computed(() => CATEGORIAS.map((categoria) => montarMeta(categoria)));

   function montarMeta(categoria) {
       const gastosDaCategoria = gastos.value.filter((gasto) => gasto.categoria === categoria.nome);
       const gasto = calcularTotal(gastosDaCategoria);
       return {
           nome: categoria.nome,
           limite: categoria.limite,
           gasto: gasto,
           porcentagem: calcularPorcentagem(gasto, categoria.limite)
       };
   }

   // montarSituacao({ gasto: 12.5, limite: 15 }) → 'Ainda dá para gastar R$ 2,50'
   function montarSituacao(meta) {
       if (meta.gasto > meta.limite) {
           return `Passou ${formatarReais(meta.gasto - meta.limite)} do limite`;
       }
       return `Ainda dá para gastar ${formatarReais(meta.limite - meta.gasto)}`;
   }
   </script>

   <template>
       <main>
           <h2>Metas da semana</h2>
           <p>Quanto já foi gasto em cada categoria, perto do limite.</p>

           <div>
               <section v-for="meta in metas" :key="meta.nome">
                   <h3>{{ meta.nome }}</h3>
                   <p>{{ Math.round(meta.porcentagem) }}%</p>
                   <p>{{ formatarReais(meta.gasto) }} de {{ formatarReais(meta.limite) }}</p>
                   <p>{{ montarSituacao(meta) }}</p>
               </section>
           </div>
       </main>
   </template>
   ```

3. No `router.js`, o import da `PaginaMetas` e a rota
   `{ path: '/metas', component: PaginaMetas }`.
4. No menu do `App.vue`, depois do Histórico:
   `<RouterLink to="/metas">Metas</RouterLink>`.

**Funcionou se:** a página Metas aparece com o visual padrão do navegador:
Alimentação com 83%, Transporte com 29%, Lazer com 150% e "Passou R$ 10,00
do limite". É o "antes".

---

## Pedaço 3 — O cartão

Só o `<template>` da `PaginaMetas.vue` muda. Nenhuma linha no `style.css`.

   ```html
   <template>
       <main>
           <h2 class="m-0 text-2xl font-bold">Metas da semana</h2>
           <p class="mt-1 text-gray-600">Quanto já foi gasto em cada categoria, perto do limite.</p>

           <div>
               <section v-for="meta in metas" :key="meta.nome" class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                   <h3 class="m-0 text-lg font-bold">{{ meta.nome }}</h3>
                   <p class="m-0 text-sm text-gray-500">{{ Math.round(meta.porcentagem) }}%</p>
                   <p class="mt-2 mb-0 text-2xl font-bold">{{ formatarReais(meta.gasto) }} <span class="text-base font-normal text-gray-500">de {{ formatarReais(meta.limite) }}</span></p>
                   <p class="mt-3 mb-0 text-sm text-gray-600">{{ montarSituacao(meta) }}</p>
               </section>
           </div>
       </main>
   </template>
   ```

**O que é cada coisa**

- **`p-6`:** padding de 24px. A escala é de 4 em 4px: `p-1` = 4px, `p-4` =
  16px.
- **`bg-white`, `text-gray-600`, `border-gray-200`:** fundo, letra e borda.
  O número é o tom: 50 é o mais claro, 950 o mais escuro.
- **`text-lg`, `text-2xl`, `font-bold`:** tamanho e peso da letra.
- **`border rounded-xl shadow-sm`:** borda de 1px, cantos arredondados e
  sombra leve.
- **`m-0`, `mt-2 mb-0`:** sem o preflight, títulos e parágrafos têm a margem
  do navegador. Aqui nós decidimos.

**Funcionou se:** cada categoria é um cartão branco. (Eles ficam grudados um
no outro: o próximo pedaço resolve.)

---

## Pedaço 4 — O layout

   ```html
   <template>
       <main class="mx-auto max-w-5xl px-5 py-8">
           <h2 class="m-0 text-2xl font-bold">Metas da semana</h2>
           <p class="mt-1 text-gray-600">Quanto já foi gasto em cada categoria, perto do limite.</p>

           <div class="mt-6 grid gap-6 md:grid-cols-3">
               <section v-for="meta in metas" :key="meta.nome" class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                   <div class="flex items-baseline justify-between">
                       <h3 class="m-0 text-lg font-bold">{{ meta.nome }}</h3>
                       <p class="m-0 text-sm text-gray-500">{{ Math.round(meta.porcentagem) }}%</p>
                   </div>
                   <p class="mt-2 mb-0 text-2xl font-bold">{{ formatarReais(meta.gasto) }} <span class="text-base font-normal text-gray-500">de {{ formatarReais(meta.limite) }}</span></p>
                   <p class="mt-3 mb-0 text-sm text-gray-600">{{ montarSituacao(meta) }}</p>
               </section>
           </div>
       </main>
   </template>
   ```

**O que é cada coisa**

- **`mx-auto max-w-5xl px-5 py-8`:** a página com no máximo 1024px de
  largura, centralizada, com espaço nas bordas.
- **`grid gap-6 md:grid-cols-3`:** no celular, um cartão embaixo do outro;
  a partir de 768px (`md:`), três lado a lado. Sem prefixo, a classe vale
  sempre; com `md:`, só do tablet para cima.
- **`flex items-baseline justify-between`:** o nome numa ponta, a
  porcentagem na outra.

**Funcionou se:** no computador, três cartões lado a lado; estreitando a
janela, eles empilham.

---

## Pedaço 5 — A barra de progresso

1. No `<script setup>`, depois da `montarSituacao`:

   ```js
   // O nome da classe vai inteiro no código: o Tailwind só cria as
   // classes que encontra escritas nos arquivos.
   function escolherCorDaBarra(porcentagem) {
       if (porcentagem > 100) {
           return 'bg-red-500';
       }
       if (porcentagem >= 80) {
           return 'bg-amber-400';
       }
       return 'bg-emerald-500';
   }

   function escolherCorDaSituacao(meta) {
       if (meta.gasto > meta.limite) {
           return 'font-bold text-red-700';
       }
       return 'text-gray-600';
   }
   ```

2. O `<template>`:

   ```html
   <template>
       <main class="mx-auto max-w-5xl px-5 py-8">
           <h2 class="m-0 text-2xl font-bold">Metas da semana</h2>
           <p class="mt-1 text-gray-600">Quanto já foi gasto em cada categoria, perto do limite.</p>

           <div class="mt-6 grid gap-6 md:grid-cols-3">
               <section v-for="meta in metas" :key="meta.nome" class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                   <div class="flex items-baseline justify-between">
                       <h3 class="m-0 text-lg font-bold">{{ meta.nome }}</h3>
                       <p class="m-0 text-sm text-gray-500">{{ Math.round(meta.porcentagem) }}%</p>
                   </div>
                   <p class="mt-2 mb-0 text-2xl font-bold">{{ formatarReais(meta.gasto) }} <span class="text-base font-normal text-gray-500">de {{ formatarReais(meta.limite) }}</span></p>

                   <!-- O trilho cinza e, dentro dele, a barra colorida -->
                   <div class="mt-4 h-3 overflow-hidden rounded-full bg-gray-200">
                       <div class="h-full rounded-full" :class="escolherCorDaBarra(meta.porcentagem)" :style="{ width: Math.min(meta.porcentagem, 100) + '%' }"></div>
                   </div>

                   <p class="mt-3 mb-0 text-sm" :class="escolherCorDaSituacao(meta)">{{ montarSituacao(meta) }}</p>
               </section>
           </div>
       </main>
   </template>
   ```

**O que é cada coisa**

- **`:style` na largura:** a porcentagem pode ser qualquer número. O
  `Math.min(..., 100)` segura a barra no trilho quando passa do limite.
- **`:class` na cor:** a função escolhe entre três classes que já existem.
- **O nome da classe vai inteiro no código.** O Tailwind procura os nomes
  escritos nos arquivos. `` `bg-${cor}-500` `` não funciona: `bg-red-500`
  nunca aparece escrito.
- **Uma cor de cada vez:** com `text-gray-600` e `text-red-700` juntos, não
  dá para saber qual ganha. A função devolve uma só.

**Funcionou se:** Alimentação com a barra amarela, Transporte verde, Lazer
vermelha e cheia. Adicionando um gasto de Transporte de R$ 10, a barra dele
fica amarela.

---

## Pedaço 6 — Hover e foco

   ```html
   <template>
       <main class="mx-auto max-w-5xl px-5 py-8">
           <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
               <div>
                   <h2 class="m-0 text-2xl font-bold">Metas da semana</h2>
                   <p class="mt-1 mb-0 text-gray-600">Quanto já foi gasto em cada categoria, perto do limite.</p>
               </div>
               <RouterLink to="/novo" class="rounded-lg bg-emerald-700 px-5 py-3 text-center font-bold text-white no-underline hover:bg-emerald-800 focus-visible:ring-4 focus-visible:ring-emerald-300 focus-visible:outline-none">
                   Novo gasto
               </RouterLink>
           </div>

           <div class="mt-6 grid gap-6 md:grid-cols-3">
               <section v-for="meta in metas" :key="meta.nome" class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-md">
                   <div class="flex items-baseline justify-between">
                       <h3 class="m-0 text-lg font-bold">{{ meta.nome }}</h3>
                       <p class="m-0 text-sm text-gray-500">{{ Math.round(meta.porcentagem) }}%</p>
                   </div>
                   <p class="mt-2 mb-0 text-2xl font-bold">{{ formatarReais(meta.gasto) }} <span class="text-base font-normal text-gray-500">de {{ formatarReais(meta.limite) }}</span></p>

                   <!-- O trilho cinza e, dentro dele, a barra colorida -->
                   <div class="mt-4 h-3 overflow-hidden rounded-full bg-gray-200">
                       <div class="h-full rounded-full" :class="escolherCorDaBarra(meta.porcentagem)" :style="{ width: Math.min(meta.porcentagem, 100) + '%' }"></div>
                   </div>

                   <p class="mt-3 mb-0 text-sm" :class="escolherCorDaSituacao(meta)">{{ montarSituacao(meta) }}</p>
               </section>
           </div>
       </main>
   </template>
   ```

**O que é cada coisa**

- **`hover:`:** a classe só vale com o mouse em cima.
- **`focus-visible:`:** só vale com o foco pelo teclado (Tab). O `ring-4` é
  um anel em volta; o `outline-none` tira o contorno padrão.
- **`transition hover:-translate-y-1 hover:shadow-md`:** o cartão sobe 4px
  e ganha sombra, suavemente.
- **`sm:flex-row`:** no celular, o botão fica embaixo do título; a partir de
  640px, ao lado.

**Funcionou se:** o botão escurece com o mouse e mostra um anel verde-claro
com Tab; o cartão "levanta" no hover.

---

## Pedaço 7 — O componente CartaoMeta

1. Crie o `src/components/CartaoMeta.vue`:

   ```html
   <script setup>
   import { formatarReais } from '../calculos.js';

   defineProps({
       meta: Object
   });

   // montarSituacao({ gasto: 12.5, limite: 15 }) → 'Ainda dá para gastar R$ 2,50'
   function montarSituacao(meta) {
       if (meta.gasto > meta.limite) {
           return `Passou ${formatarReais(meta.gasto - meta.limite)} do limite`;
       }
       return `Ainda dá para gastar ${formatarReais(meta.limite - meta.gasto)}`;
   }

   // O nome da classe vai inteiro no código: o Tailwind só cria as
   // classes que encontra escritas nos arquivos.
   function escolherCorDaBarra(porcentagem) {
       if (porcentagem > 100) {
           return 'bg-red-500';
       }
       if (porcentagem >= 80) {
           return 'bg-amber-400';
       }
       return 'bg-emerald-500';
   }

   function escolherCorDaSituacao(meta) {
       if (meta.gasto > meta.limite) {
           return 'font-bold text-red-700';
       }
       return 'text-gray-600';
   }
   </script>

   <template>
       <section class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-md">
           <div class="flex items-baseline justify-between">
               <h3 class="m-0 text-lg font-bold">{{ meta.nome }}</h3>
               <p class="m-0 text-sm text-gray-500">{{ Math.round(meta.porcentagem) }}%</p>
           </div>
           <p class="mt-2 mb-0 text-2xl font-bold">{{ formatarReais(meta.gasto) }} <span class="text-base font-normal text-gray-500">de {{ formatarReais(meta.limite) }}</span></p>

           <!-- O trilho cinza e, dentro dele, a barra colorida -->
           <div class="mt-4 h-3 overflow-hidden rounded-full bg-gray-200">
               <div class="h-full rounded-full" :class="escolherCorDaBarra(meta.porcentagem)" :style="{ width: Math.min(meta.porcentagem, 100) + '%' }"></div>
           </div>

           <p class="mt-3 mb-0 text-sm" :class="escolherCorDaSituacao(meta)">{{ montarSituacao(meta) }}</p>
       </section>
   </template>
   ```

2. A `PaginaMetas.vue` inteira fica assim:

   ```html
   <script setup>
   import { computed } from 'vue';
   import { calcularTotal, calcularPorcentagem } from '../calculos.js';
   import CartaoMeta from '../components/CartaoMeta.vue';
   import { gastos, CATEGORIAS } from '../gastos.js';

   // Uma meta para cada categoria: o limite, quanto já foi gasto e a porcentagem.
   const metas = computed(() => CATEGORIAS.map((categoria) => montarMeta(categoria)));

   function montarMeta(categoria) {
       const gastosDaCategoria = gastos.value.filter((gasto) => gasto.categoria === categoria.nome);
       const gasto = calcularTotal(gastosDaCategoria);
       return {
           nome: categoria.nome,
           limite: categoria.limite,
           gasto: gasto,
           porcentagem: calcularPorcentagem(gasto, categoria.limite)
       };
   }
   </script>

   <template>
       <main class="mx-auto max-w-5xl px-5 py-8">
           <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
               <div>
                   <h2 class="m-0 text-2xl font-bold">Metas da semana</h2>
                   <p class="mt-1 mb-0 text-gray-600">Quanto já foi gasto em cada categoria, perto do limite.</p>
               </div>
               <RouterLink to="/novo" class="rounded-lg bg-emerald-700 px-5 py-3 text-center font-bold text-white no-underline hover:bg-emerald-800 focus-visible:ring-4 focus-visible:ring-emerald-300 focus-visible:outline-none">
                   Novo gasto
               </RouterLink>
           </div>

           <div class="mt-6 grid gap-6 md:grid-cols-3">
               <CartaoMeta v-for="meta in metas" :key="meta.nome" :meta="meta" />
           </div>
       </main>
   </template>
   ```

**Por quê:** o template com muitas classes é a crítica mais comum ao
Tailwind. Com o componente, as classes moram num lugar só, e quem usa o
cartão escreve uma linha.

**Funcionou se:** a página continua igual.

---

## Extra — A página Relatório

Uma segunda página com Tailwind, para consultar e copiar ideias: gradiente,
grade com `sm:` e `lg:`, botões em pílula, uma barra dividida em fatias,
lista com divisórias, texto cortado com "..." e um link que aparece no
hover. Cada parte está explicada nos comentários e no slide 25.

1. Crie o `src/components/CartaoDestaque.vue`:

   ```html
   <!--
       Um número em destaque no Relatório: um rótulo pequeno em cima e
       o valor grande embaixo.

       Com a prop destaque, o cartão troca o fundo branco por um
       gradiente verde. O componente escolhe as classes inteiras: quem
       usa só diz se é destaque ou não.
   -->
   <script setup>
   defineProps({
       rotulo: String,
       valor: [String, Number],
       destaque: { type: Boolean, default: false }
   });

   function escolherEstiloDoCartao(destaque) {
       if (destaque) {
           return 'bg-linear-to-br from-emerald-600 to-emerald-800 text-white shadow-md';
       }
       return 'border border-gray-200 bg-white shadow-sm';
   }

   function escolherCorDoRotulo(destaque) {
       if (destaque) {
           return 'text-emerald-100';
       }
       return 'text-gray-500';
   }
   </script>

   <template>
       <div class="rounded-xl p-5" :class="escolherEstiloDoCartao(destaque)">
           <p class="m-0 text-xs font-bold tracking-wider uppercase" :class="escolherCorDoRotulo(destaque)">{{ rotulo }}</p>
           <p class="mt-2 mb-0 truncate text-2xl font-bold">{{ valor }}</p>
       </div>
   </template>
   ```

2. Crie o `src/pages/PaginaRelatorio.vue`:

   ```html
   <!--
       A página Relatório, no endereço /relatorio: mais coisas que dá
       para fazer com classes do Tailwind.

       - os destaques: uma grade com 1, 2 ou 4 colunas (sm: e lg:) e um
         cartão com gradiente;
       - para onde foi o dinheiro: uma barra dividida em fatias (flex);
       - o filtro: botões em forma de pílula, com active:;
       - a lista: divisórias (divide-y), texto cortado (truncate), uma
         coluna que some no celular (hidden sm:inline) e um link que, no
         computador, só aparece com o mouse em cima da linha (group-hover:).
   -->
   <script setup>
   import { ref, computed } from 'vue';
   import { formatarReais, calcularTotal, calcularPorcentagem, montarTextoDoGasto, calcularMaiorGasto, passaNoFiltro } from '../calculos.js';
   import CartaoDestaque from '../components/CartaoDestaque.vue';
   import { gastos, CATEGORIAS } from '../gastos.js';

   const categoriaEscolhida = ref('Todas');

   const total = computed(() => calcularTotal(gastos.value));

   // As categorias, da que mais gastou para a que menos gastou.
   const ranking = computed(() => CATEGORIAS
       .map((categoria) => montarFatia(categoria))
       .toSorted((a, b) => b.total - a.total));

   const mostrados = computed(() => gastos.value.filter((gasto) => passaNoFiltro(gasto, categoriaEscolhida.value)));

   function montarFatia(categoria) {
       const totalDaCategoria = calcularTotal(gastos.value.filter((gasto) => gasto.categoria === categoria.nome));
       return {
           nome: categoria.nome,
           total: totalDaCategoria,
           porcentagem: calcularPorcentagem(totalDaCategoria, total.value)
       };
   }

   function montarTextoDoMaior(lista) {
       if (lista.length === 0) {
           return '—';
       }
       return montarTextoDoGasto(calcularMaiorGasto(lista));
   }

   // A primeira do ranking, se alguma categoria tiver gasto.
   function montarTextoDaCampea(lista) {
       if (lista[0].total === 0) {
           return '—';
       }
       return lista[0].nome;
   }

   function escolherCategoria(nome) {
       categoriaEscolhida.value = nome;
   }

   // Os nomes das classes vão inteiros: o Tailwind só cria o que
   // encontra escrito nos arquivos.
   function escolherCorDaCategoria(nome) {
       if (nome === 'Alimentação') {
           return 'bg-orange-500';
       }
       if (nome === 'Transporte') {
           return 'bg-blue-500';
       }
       return 'bg-purple-500';
   }

   function escolherEstiloDoFiltro(nome) {
       if (nome === categoriaEscolhida.value) {
           return 'border-emerald-700 bg-emerald-700 text-white hover:bg-emerald-800';
       }
       return 'border-gray-300 bg-white text-gray-700 hover:bg-gray-100';
   }
   </script>

   <template>
       <main class="mx-auto max-w-5xl space-y-8 px-5 py-8">

           <!-- Os destaques: 1 coluna no celular, 2 a partir de 640px, 4 a partir de 1024px -->
           <section>
               <h2 class="m-0 text-2xl font-bold">Relatório da semana</h2>
               <div class="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                   <CartaoDestaque rotulo="Total gasto" :valor="formatarReais(total)" destaque />
                   <CartaoDestaque rotulo="Gastos" :valor="gastos.length" />
                   <CartaoDestaque rotulo="Maior gasto" :valor="montarTextoDoMaior(gastos)" />
                   <CartaoDestaque rotulo="Mais gastou em" :valor="montarTextoDaCampea(ranking)" />
               </div>
           </section>

           <!-- Para onde foi o dinheiro: uma barra só, com uma fatia por categoria -->
           <section class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
               <h3 class="m-0 text-lg font-bold">Para onde foi o dinheiro</h3>
               <div class="mt-4 flex h-4 overflow-hidden rounded-full bg-gray-200">
                   <div v-for="fatia in ranking" :key="fatia.nome" :class="escolherCorDaCategoria(fatia.nome)" :style="{ width: fatia.porcentagem + '%' }"></div>
               </div>
               <ul class="mt-4 mb-0 flex list-none flex-wrap gap-x-6 gap-y-2 p-0">
                   <li v-for="fatia in ranking" :key="fatia.nome" class="inline-flex items-center gap-2 text-sm text-gray-700">
                       <span class="size-3 rounded-full" :class="escolherCorDaCategoria(fatia.nome)"></span>
                       {{ fatia.nome }}: <strong>{{ Math.round(fatia.porcentagem) }}%</strong>
                   </li>
               </ul>
           </section>

           <!-- O filtro e a lista -->
           <section>
               <div class="flex flex-wrap gap-2">
                   <button
                       v-for="nome in ['Todas', 'Alimentação', 'Transporte', 'Lazer']"
                       :key="nome"
                       type="button"
                       class="w-auto cursor-pointer rounded-full border px-4 py-1.5 text-sm font-bold transition active:scale-95"
                       :class="escolherEstiloDoFiltro(nome)"
                       @click="escolherCategoria(nome)"
                   >
                       {{ nome }}
                   </button>
               </div>

               <ul v-if="mostrados.length > 0" class="mt-4 mb-0 list-none divide-y divide-gray-200 overflow-hidden rounded-xl border border-gray-200 bg-white p-0">
                   <li v-for="gasto in mostrados" :key="gasto.id" class="group flex items-center gap-4 px-4 py-3 hover:bg-gray-50">
                       <span class="size-3 shrink-0 rounded-full" :class="escolherCorDaCategoria(gasto.categoria)"></span>
                       <span class="min-w-0 flex-1 truncate">{{ gasto.descricao }}</span>
                       <span class="hidden text-sm text-gray-500 sm:inline">{{ gasto.categoria }}</span>
                       <strong class="tabular-nums">{{ formatarReais(gasto.valor) }}</strong>
                       <RouterLink :to="`/gasto/${gasto.id}`" class="text-sm text-emerald-700 sm:opacity-0 sm:group-hover:opacity-100 sm:focus-visible:opacity-100">ver</RouterLink>
                   </li>
               </ul>

               <p v-else class="mt-4 mb-0 rounded-xl border-2 border-dashed border-gray-300 py-10 text-center text-gray-500">
                   Nenhum gasto nesta categoria.
               </p>
           </section>

       </main>
   </template>
   ```

3. A rota `{ path: '/relatorio', component: PaginaRelatorio }` no
   `router.js`, e o link `<RouterLink to="/relatorio">Relatório</RouterLink>`
   no menu do `App.vue`.

**Testes que vale fazer:** mude a largura da janela (os destaques vão de 4
para 2 e para 1 coluna; a categoria some da lista abaixo de 640px); passe o
mouse nas linhas da lista; adicione um gasto com uma descrição bem longa.

---

## O que mudou, no fim

| arquivo | o que mudou |
|---|---|
| `package.json` | `tailwindcss` e `@tailwindcss/vite` |
| `vite.config.js` | o plugin `tailwindcss()` |
| `style.css` | as três linhas do Tailwind no topo; o CSS antigo dentro do `@layer base` |
| `gastos.js` | um `limite` em cada categoria |
| `router.js` e `App.vue` | a rota `/metas` e o link no menu |
| `pages/PaginaMetas.vue` | a página, só com classes do Tailwind |
| `components/CartaoMeta.vue` | o cartão de uma meta |
