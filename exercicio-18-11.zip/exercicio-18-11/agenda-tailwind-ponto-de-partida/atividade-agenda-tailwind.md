# Agenda de entregas — a página Por tipo, com Tailwind

A agenda vai ganhar uma página nova, **Por tipo** (`#/tipos`): um cartão para
as provas, um para os trabalhos e um para as apresentações. Cada cartão
mostra quantas entregas estão pendentes, quantas já foram feitas (com uma
barra) e a lista das pendentes, da mais próxima para a mais distante.

Todo o estilo da página nova é feito **só com classes do Tailwind**: nenhuma
linha nova no `style.css`.

**Ponto de partida:** a sua agenda em páginas de segunda ou, se você não
tiver, a pasta `agenda-tailwind-ponto-de-partida` (`npm install` e
`npm run dev` dentro dela).

O `tailwind-passo-a-passo.md` continua valendo como consulta: cada passo
daqui tem um pedaço parecido lá. E a documentação do Tailwind
(tailwindcss.com/docs) tem uma busca no topo: procure pelo que você quer
fazer ("padding", "border radius", "grid").

---

## Passo 1 — O Tailwind instalado

- `npm install tailwindcss @tailwindcss/vite`.
- O plugin `tailwindcss()` no `vite.config.js`.
- No topo do `style.css`, as três linhas do Tailwind sem o preflight. O CSS
  que já existia vai para dentro de um `@layer base { ... }`.

> **Dica:** é o pedaço 1 dos gastos, igualzinho. A chave do `@layer base`
> abre depois das três linhas e fecha no fim do arquivo.

**Funcionou se:** a agenda continua igual, e um `class="underline"` no
`<h1>` do `App.vue` sublinha o título (depois, tire).

---

## Passo 2 — A página Por tipo, sem estilo

- Uma página nova, `PaginaTipos.vue`, no endereço `/tipos`, com um link
  **Por tipo** no menu.
- Uma lista com os três tipos:

  ```js
  const TIPOS = [
      { tipo: 'prova', titulo: 'Provas' },
      { tipo: 'trabalho', titulo: 'Trabalhos' },
      { tipo: 'apresentacao', titulo: 'Apresentações' }
  ];
  ```

- Um `computed` que monta, para cada tipo: o título, o total de entregas
  daquele tipo, quantas já foram feitas e a lista das pendentes, ordenada
  por data.
- Para cada tipo, uma `<section>` com o título (`<h3>`), "Pendentes: 1", "1
  de 2 feitas" e a lista das pendentes ("Matemática — 18/11"). Sem
  pendentes, "Nada pendente."

> **Dicas**
>
> - É o pedaço 2 dos gastos: um `map` sobre os tipos e um `filter` para as
>   entregas de cada um.
> - O `agenda.js` já tem a `ordenarPorData`, a `filtrarPendentes` e a
>   `formatarData`.

**Funcionou se:** a página aparece com o visual padrão do navegador, com os
números certos: Provas com 1 pendente, Trabalhos com "1 de 2 feitas".

---

## Passo 3 — Os cartões e a grade

- O `<main>` centralizado, com largura máxima e espaço nas bordas.
- Cada `<section>` vira um cartão: fundo branco, borda cinza-clara, cantos
  arredondados, sombra leve e espaço por dentro.
- O título e o "Pendentes: 1" na mesma linha, um em cada ponta. O
  "Pendentes" num selo arredondado (`rounded-full`), com fundo cinza.
- Cada pendente numa linha com fundo cinza bem claro: a matéria em negrito
  à esquerda, a data à direita. A lista sem os marcadores.
- No computador, os três cartões lado a lado; no celular, um embaixo do
  outro.

> **Dicas**
>
> - Pedaços 3 e 4 dos gastos: `p-6`, `bg-white`, `border border-gray-200`,
>   `rounded-xl`, `shadow-sm`, `flex justify-between`, `grid gap-6
>   md:grid-cols-3`, `mx-auto max-w-5xl`.
> - A lista: `list-none p-0` tira os marcadores e o recuo; `space-y-2`
>   põe espaço entre os itens.
> - Sem o preflight, títulos e parágrafos têm margem do navegador: use
>   `m-0`, `mt-2`, `mb-0`...

**Funcionou se:** três cartões lado a lado no computador; estreitando a
janela, eles ficam empilhados.

---

## Passo 4 — A cor de cada tipo e a barra

- O selo "Pendentes" ganha a cor do tipo, com texto branco: vermelho para
  provas, azul para trabalhos, roxo para apresentações.
- Embaixo do "1 de 2 feitas", uma barra fininha (um trilho cinza com a
  barra dentro), na cor do tipo, com a largura da porcentagem de feitas.

> **Dicas**
>
> - É o pedaço 5 dos gastos: a cor no `:class`, a largura no `:style`.
> - Uma função `escolherCorDoTipo(tipo)` que devolve `'bg-red-600'`,
>   `'bg-blue-600'` ou `'bg-purple-600'`. O mesmo resultado serve para o
>   selo e para a barra.
> - **Escreva o nome da classe inteiro.** `` `bg-${cor}-600` `` não
>   funciona: o Tailwind só cria as classes que encontra escritas.
> - Cuidado com o tipo sem nenhuma entrega: `0 / 0` dá `NaN`. Uma função
>   `calcularPorcentagemFeita` que devolve 0 quando o total é 0.

**Funcionou se:** cada cartão tem a sua cor; Trabalhos com a barra pela
metade; marcando a Matemática como feita, Provas fica com a barra cheia e
"Nada pendente.".

---

## Passo 5 — O componente CartaoTipo

- O cartão vira um componente, `CartaoTipo.vue`, que recebe o resumo por
  prop. A página fica só com o título e a grade:
  `<CartaoTipo v-for="resumo in resumos" :key="resumo.tipo" :resumo="resumo" />`.
- O cartão sobe um pouco e ganha mais sombra quando o mouse passa por cima.

> **Dicas**
>
> - Pedaços 6 e 7 dos gastos: `transition hover:-translate-y-1
>   hover:shadow-md`.
> - A `escolherCorDoTipo`, a `calcularPorcentagemFeita` e o import da
>   `formatarData` vão junto para o componente.

**Funcionou se:** a página continua igual, e o cartão "levanta" no hover.

---

## Se sobrar tempo

- **Um botão Nova entrega** ao lado do título da página, laranja como o
  botão Adicionar, que escurece no `hover:` e mostra um anel no
  `focus-visible:` (navegue com Tab para testar). No celular, embaixo do
  título; no computador, na mesma linha (`sm:flex-row`).
- **As matérias viram links** para a página da entrega
  (``:to="`/entrega/${entrega.id}`"``), sublinhados só no `hover:`.
- **Um cartão diferente para quem está em dia:** quando não há nada
  pendente, o cartão fica com a borda verde (`border-emerald-400`). Use uma
  função que devolve a classe da borda inteira.

---

## Para entregar

Faça o commit e envie para o GitHub, mesmo que incompleto. Um commit por
passo.
